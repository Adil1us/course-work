import pygame as p
import copy
import math
import random

glider_coords = [(5, 6), (6, 7), (7, 5), (7, 6), (7, 7)]
gosper_coords = [
    (1, 5),
    (2, 5),
    (1, 6),
    (2, 6),
    (13, 3),
    (14, 3),
    (12, 4),
    (16, 4),
    (11, 5),
    (17, 5),
    (11, 6),
    (15, 6),
    (17, 6),
    (18, 6),
    (11, 7),
    (17, 7),
    (12, 8),
    (16, 8),
    (13, 9),
    (14, 9),
    (25, 1),
    (23, 2),
    (25, 2),
    (21, 3),
    (22, 3),
    (21, 4),
    (22, 4),
    (21, 5),
    (22, 5),
    (23, 6),
    (25, 6),
    (25, 7),
    (35, 3),
    (36, 3),
    (35, 4),
    (36, 4),
]
star_coords = [
    (8, 4),
    (9, 4),
    (10, 4),
    (6, 6),
    (8, 6),
    (10, 6),
    (12, 6),
    (4, 8),
    (4, 9),
    (4, 10),
    (6, 8),
    (6, 10),
    (6, 12),
    (8, 12),
    (10, 12),
    (12, 12),
    (12, 10),
    (12, 8),
    (14, 8),
    (14, 9),
    (14, 10),
    (8, 14),
    (9, 14),
    (10, 14),
]

# класс кнопок
class button:
    def __init__(self, color, x, y, width, height, text=""):
        # цвет RGB (0-255, 0-255, 0-255)
        self.color = color
        # координаты
        self.x = x
        self.y = y
        # ширина
        self.width = width
        # высота
        self.height = height
        # текст
        self.text = text

    def draw(self, win, outline=None):
        # если с контуром, отрисовка происходит по другому
        if outline:
            p.draw.rect(
                win,
                outline,
                (self.x - 2, self.y - 2, self.width + 4, self.height + 4),
                0,
            )
        p.draw.rect(win, self.color, (self.x, self.y, self.width, self.height), 0)
        if self.text != "":
            font = p.font.SysFont("helvetica", self.width - 70)
            text = font.render(self.text, 1, (0, 0, 0))
            win.blit(
                text,
                (
                    self.x + (self.width / 2 - text.get_width() / 2),
                    self.y + (self.height / 2 - text.get_height() / 2),
                ),
            )

    # проверка на позицию мыши над кнопкой
    def isOver(self, pos):
        if pos[0] > self.x and pos[0] < self.x + self.width:
            if pos[1] > self.y and pos[1] < self.y + self.height:
                return True
        return False


# класс игры - жизнь
class conways_life:
    def __init__(self):
        # инициализация окна
        p.init()
        # название окна
        p.display.set_caption("Игра 'Жизнь'")
        # задание размеров окна
        self.screen = p.display.set_mode((1000, 670))
        # размеры поля
        self.field_width = 200
        self.field_height = 107
        # буфер в котором определяется жива клетка или нет (0 мертва, 1 жива)
        self.data = [
            [0 for j in range(self.field_width)] for i in range(self.field_height)
        ]
        # переменная отвечающая за запуск программы
        self.run = True
        # переменная времени
        self.clock = p.time.Clock()
        # запуск игры
        self.start = False
        # переменная инициализации
        self.initial = True
        # переменная для хранения текста кнопки
        self.start_button_text = "Старт"
        self.show_text_window = False
        # кнопка очистки
        self.resetButton = button((255, 255, 255), 33, 553, 95, 75, "Сброс")
        # кнопка запуска
        self.startButton = button(
            (255, 255, 255), 233, 553, 95, 75, self.start_button_text
        )
        # кнопка случайной генерации
        self.randomButton = button((255, 255, 255), 443, 553, 95, 75, "Рандом")
        # кнопка Шага
        self.stepButton = button((255, 255, 255), 653, 553, 95, 75, "Шаг")
        # Кнопка Планера
        self.gliderButton = button((255, 255, 255), 813, 43, 95, 75, "Планер")
        # Кнопка Ружья Госпера
        self.gosperButton = button((255, 255, 255), 813, 163, 95, 75, "Ружье")
        # Кнопка Звезда
        self.starButton = button((255, 255, 255), 813, 283, 95, 75, "Звезда")
        # Кнопка Инфо
        self.textWindowButton = button((255, 255, 255), 813, 403, 95, 75, "Инфо")

    def getData(self):
        return self.data

    # функция поиска соседей
    def get_neighbour(self, i, j):
        neighbour = [
            [i + 1, j],
            [i - 1, j],
            [i, j + 1],
            [i, j - 1],
            [i + 1, j + 1],
            [i - 1, j + 1],
            [i + 1, j - 1],
            [i - 1, j - 1],
        ]
        neighbour = [
            i
            for i in neighbour
            if 0 <= i[0] < self.field_height and 0 <= i[1] < self.field_width
        ]
        return neighbour

    # функция новой эволюции клетки
    def next_generation(self):
        # возвращаем прошлую версию массива
        self.last_generation = copy.deepcopy(self.data)
        # проходимся по массиву
        for i in range(len(self.data)):
            for j in range(len(self.data[i])):
                # ищем количество соседних клеток
                self.count = [
                    self.last_generation[k[0]][k[1]] for k in self.get_neighbour(i, j)
                ].count(1)
                # в зависимости от количества соседних, оживляем
                if self.last_generation[i][j] == 1:
                    self.data[i][j] = 1 if self.count in range(2, 4) else 0
                elif self.last_generation[i][j] == 0:
                    self.data[i][j] = 1 if self.count == 3 else 0

    # обновление окна
    def update(self):
        # закрашивание окна черным цветом
        self.screen.fill((20, 20, 20))
        # вывод клеток
        for i in range(self.field_height):
            if len(self.data[i]) == self.field_width:
                for j in range((self.field_width) - 50):
                    if self.data[i][j] == 1:
                        p.draw.rect(self.screen, (46, 166, 50), (j * 5, i * 5, 5, 5))
        # Рисуем сетку
        for i in range(0, (self.screen.get_height() - 130) // 5):
            p.draw.line(self.screen, (31, 32, 33), (1, i * 5), (750, i * 5))
        for j in range(0, (self.screen.get_width() - 245) // 5):
            p.draw.line(self.screen, (31, 32, 33), (j * 5 - 1, 0), (j * 5 - 1, 535))
        # установка кнопок
        self.resetButton.draw(self.screen, (0, 0, 0))
        self.startButton.draw(self.screen, (0, 0, 0))
        self.randomButton.draw(self.screen, (0, 0, 0))
        self.stepButton.draw(self.screen, (0, 0, 0))
        self.gliderButton.draw(self.screen, (0, 0, 0))
        self.gosperButton.draw(self.screen, (0, 0, 0))
        self.starButton.draw(self.screen, (0, 0, 0))
        self.textWindowButton.draw(self.screen, (0, 0, 0))
        if self.show_text_window:
            # Создаем поверхность для окна
            window_surface = p.Surface((730, 300))
            window_surface.fill((200, 200, 200))

            # Отрисовываем текст в окне
            font = p.font.SysFont("helvetica", 20)
            text0 = font.render("Информация об игре", 1, (0, 0, 0))
            text1 = font.render(
                "Игра «Жизнь» — это игра без игроков, в которой человек создаёт начальное состояние,",
                1,
                (0, 0, 0),
            )
            text2 = font.render(
                " а потом лишь наблюдает за её развитием.",
                1,
                (0, 0, 0),
            )
            text3 = font.render(
                "Правила Игры 'Жизнь':",
                1,
                (0, 0, 0),
            )
            text4 = font.render(
                "- В пустой (мёртвой) клетке, рядом с которой ровно три живые клетки, зарождается жизнь;",
                1,
                (0, 0, 0),
            )
            text5 = font.render(
                "- Если у живой клетки есть две или три живые соседки, то эта клетка продолжает жить;",
                1,
                (0, 0, 0),
            )
            text6 = font.render(
                "- Клетка умирает если соседей меньше двух или больше трёх.",
                1,
                (0, 0, 0),
            )
            text7 = font.render(
                "Автор: студент гр.5.205-2 Жамбулатов Адиль",
                1,
                (0, 0, 0),
            )
            window_surface.blit(text0, (290, 10))
            window_surface.blit(text1, (13, 35))
            window_surface.blit(text2, (13, 55))
            window_surface.blit(text3, (13, 95))
            window_surface.blit(text4, (13, 115))
            window_surface.blit(text5, (13, 135))
            window_surface.blit(text6, (13, 155))
            window_surface.blit(text7, (13, 195))
            # Отрисовываем окно на экране
            self.screen.blit(window_surface, (60, 200))

            # Обработка события закрытия окна
            for event in p.event.get():
                if event.type == p.MOUSEBUTTONDOWN:
                    mouse_pos = p.mouse.get_pos()
                    self.show_text_window = False

    # функция действий пользователя - расстановка клеток и удаление
    def user_initial(self):
        if self.initial:
            x, y = p.mouse.get_pos()
            # до 535 по Y расположено поле
            if y < 535:
                if p.mouse.get_pressed()[0]:
                    self.data[math.floor(y / 5)][math.floor(x / 5)] = 1
                if p.mouse.get_pressed()[2]:
                    self.data[math.floor(y / 5)][math.floor(x / 5)] = 0
            self.clock.tick(120)

    # функция запуска
    def start_game(self):
        while self.run:
            # обработка событий окна
            for event in p.event.get():
                # получение координат мыши окна
                pos = p.mouse.get_pos()
                # если нажата кнопка
                if event.type == p.MOUSEBUTTONDOWN:
                    # если координаты мыши совпадают с координатами кнопки, то происходят соответствующие действия
                    # Нажата Reset
                    if self.resetButton.isOver(pos):
                        # передаем новый массив с нулям
                        self.start_button_text = "Старт"
                        self.data = [
                            [0 for j in range(self.field_width)]
                            for i in range(self.field_height)
                        ]
                        # выводим в консоль для отслеживания действий
                        print("очистка поля")
                        # указываем что игра завершена в этот момент
                        self.start = False
                        # указываем что пользователь может расставлять клетки, эта переменная активирует действия в функции сверху
                        self.initial = True
                    # Нажата Старт
                    if self.startButton.isOver(pos):
                        # если запуск уже произведен, т.е. значение self.start = true, то меняем значение на false, иначе true
                        if self.start:
                            self.start = False
                            self.initial = True
                            self.start_button_text = "Старт"
                        else:
                            self.start = True
                            self.initial = False
                            self.start_button_text = "Пауза"
                        # Обновляем текст кнопки
                        self.startButton.text = self.start_button_text
                        # вывод в консоль переменной для отслеживания действий той самой self.start
                        print(self.start)
                    # Нажат Random
                    if self.randomButton.isOver(pos):
                        # заполнение буфера в котором клетки случайными цифрами 0 или 1
                        for i in range(len(self.data)):
                            for j in range((len(self.data[i]) - 50)):
                                self.data[i][j] = random.randint(0, 1)
                        print("Случаное расположение живых клеток")
                    # Нажат Шаг
                    if self.stepButton.isOver(pos):
                        self.next_generation()
                        print("Шаг")
                    # Нажата Glider
                    if self.gliderButton.isOver(pos):
                        self.data = [
                            [0 for j in range(self.field_width)]
                            for i in range(self.field_height)
                        ]
                        for x, y in glider_coords:
                            if 0 <= y < self.field_height and 0 <= x < self.field_width:
                                self.data[y][x] = 1
                                print("Генерация фигуры 'Планер'")
                    # Нажата Gosper
                    if self.gosperButton.isOver(pos):
                        self.data = [
                            [0 for j in range(self.field_width)]
                            for i in range(self.field_height)
                        ]
                        for x, y in gosper_coords:
                            if 0 <= y < self.field_height and 0 <= x < self.field_width:
                                self.data[y][x] = 1
                                print("Генерация фигуры 'Планерное ружье'")
                    # Нажата Звезда
                    if self.starButton.isOver(pos):
                        self.data = [
                            [0 for j in range(self.field_width)]
                            for i in range(self.field_height)
                        ]
                        for x, y in star_coords:
                            if 0 <= y < self.field_height and 0 <= x < self.field_width:
                                self.data[y][x] = 1
                                print("Генерация фигуры 'Звезда'")
                    # Нажата кнопка "Текст"
                    if self.textWindowButton.isOver(pos):
                        self.show_text_window = True
                # Подсветка кнопок
                if event.type == p.MOUSEMOTION:
                    pos = p.mouse.get_pos()
                    if self.resetButton.isOver(pos):
                        self.resetButton.color = (200, 200, 200)
                    else:
                        self.resetButton.color = (255, 255, 255)
                    if self.startButton.isOver(pos):
                        self.startButton.color = (200, 200, 200)
                    else:
                        self.startButton.color = (255, 255, 255)
                    if self.randomButton.isOver(pos):
                        self.randomButton.color = (200, 200, 200)
                    else:
                        self.randomButton.color = (255, 255, 255)
                    if self.stepButton.isOver(pos):
                        self.stepButton.color = (200, 200, 200)
                    else:
                        self.stepButton.color = (255, 255, 255)
                    if self.gliderButton.isOver(pos):
                        self.gliderButton.color = (200, 200, 200)
                    else:
                        self.gliderButton.color = (255, 255, 255)
                    if self.gosperButton.isOver(pos):
                        self.gosperButton.color = (200, 200, 200)
                    else:
                        self.gosperButton.color = (255, 255, 255)
                    if self.starButton.isOver(pos):
                        self.starButton.color = (200, 200, 200)
                    else:
                        self.starButton.color = (255, 255, 255)
                    if self.textWindowButton.isOver(pos):
                        self.textWindowButton.color = (200, 200, 200)
                    else:
                        self.textWindowButton.color = (255, 255, 255)
                # если окно закрыто, программа завершается
                if event.type == p.QUIT:
                    self.run = False
            # обновление объектов в окне
            self.update()
            # вызов функции в которой происходит расположение пользователем клеток, в случае initial = True
            self.user_initial()
            # если игра начата
            if self.start and any(1 in row for row in self.data):
                # происходит вызов функции в которой происходит новое поколение клеток
                self.next_generation()
                # задержка(иначе будет все слишком быстро)
                self.clock.tick(30)
            elif not self.start and any(1 in row for row in self.data):
                self.initial = True
            # обновление окна
            p.display.update()


if __name__ == "__main__":
    # создаем объекты класса игры
    game = conways_life()
    # вызываем функцию запуска игры
    game.start_game()
